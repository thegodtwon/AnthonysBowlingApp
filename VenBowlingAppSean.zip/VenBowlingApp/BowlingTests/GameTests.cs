using BowlingClasses;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingTests
{
    [TestClass]
    public class GameTests
    {

        private Game game;

        [TestInitialize]
        public void Initialize()
        {
            game = new Game();
        }

        [TestMethod]
        public void GameScoreTest()
        {
            // Arrange
            var rollOne = 8;
            var rollTwo = 1;

            // Act
            game.Bowl(rollOne);
            game.Bowl(rollTwo);

            // Assert
            Assert.AreEqual(rollOne + rollTwo, game.GameScore, $"The expected game score is {rollOne + rollTwo}");
        }

        [TestMethod]
        public void CanRollPerfectGame()
        {
            //Arrange
            
            //Act
            RollMany(10, 21);

            //Assert
            Assert.AreEqual(300, game.GameScore, $"The expected game score is {300}");
        }

        private void RollMany(int pins, int rolls)
        {
            for (var i = 0; i < rolls; i++)
                game.Bowl(pins);
        }
    }
}