﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingClasses
{
    public class Game
    {
        //Properties for keeping track of fram
        public Frame[] Frames { get; set; }
        public string PlayerName { get; set; }
        public int PlayerScore { get; set; }
        public bool EndOfGame { get; set; }
        public int FrameIndex { get; set; }
        public int AvailablePens { get; set; }
        public int NumberOfRolls { get; set; }
        public bool IsExtraRoll { get; set; }
        public int GameScore { get => Frames.Where(f => f != null).Sum(s => s.TotalFrameScore); } //lambda expressions using LINQ to calculate the score

        //constructor that sets number of frames in a game, available pens at start of each frame and set EndOfGame to false
        public Game()
        {
            AvailablePens = 10;
            Frames = new Frame[10];
            EndOfGame = false;
            NumberOfRolls = 0;
            FrameIndex = 1;
        }

        public void Bowl(int pensbowled)
        {
            Roll(new Roll(){ PinCount = pensbowled});
            
        }
        public void Roll(Roll roll)
        {
            //increment number of rolls, up to 21 maximum in a game
            NumberOfRolls++;
            roll.RollType = RollType.normal;
            
            //test for end of game or extra roll
            if (NumberOfRolls == 21)
            {
                EndOfGame = true;
                roll.RollType = RollType.extra;
                Frames[9].ExtraRoll = roll.PinCount;
            }
            //determining that we are in roll one of a  frame using modular division
            else if((NumberOfRolls % 2) == 1)
            {
                roll.RollType = roll.PinCount == 10 ? RollType.strike : RollType.normal;//checking if roll is a strike in the first roll of a frame
                Frames[FrameIndex - 1] = new Frame() { RollOne=roll}; 

                if(IsExtraRoll)
                {
                    Frames[FrameIndex - 2].ExtraRoll = roll.PinCount;
                }
            }

            //This block of code determines whether we've rolled a spare, strike, or normal roll in a given frame
            else
            {
                if (Frames[FrameIndex - 1].RollOne.PinCount == 10 && roll.PinCount == 10)
                {
                    roll.RollType = RollType.strike;
                }
                else
                {
                    if (Frames[FrameIndex -1].RollOne.PinCount + roll.PinCount == 10)
                    {
                        roll.RollType = RollType.spare;
                    }
                    else
                    {
                        roll.RollType = RollType.normal;
                    }
                }
                Frames[FrameIndex - 1].RollTwo = roll;
                //If the first roll is a strike or the second roll is a spare then then the roll is an extra roll to score
                IsExtraRoll = (Frames[FrameIndex - 1].RollOne.RollType == RollType.strike) || roll.RollType == RollType.spare;

                FrameIndex++;
                //checking for end of game
                EndOfGame = ((NumberOfRolls == 21) || 
                    ((NumberOfRolls == 20) && (Frames[9].RollTwo.RollType == RollType.normal))) 
                    && !IsExtraRoll;
            }
        }

    }
}


