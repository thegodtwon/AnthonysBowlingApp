﻿using System;

namespace BowlingClasses
{
    public class Frame
    {
        //properties used to  
        public Roll RollOne { get; set; }
        public Roll RollTwo { get; set; }
        public int TotalFrameScore { get => ((RollOne == null) ? 0 : RollOne.PinCount) + ((RollTwo == null) ? 0 : RollTwo.PinCount) + ExtraRoll; }//using getter with conditional operators to calculate frame score
        public int ExtraRoll { get; set; }
    }
}
