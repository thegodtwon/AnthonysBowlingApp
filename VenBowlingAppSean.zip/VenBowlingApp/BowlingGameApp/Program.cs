﻿using BowlingClasses;
using System;

namespace BowlingGameApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Start of game. Enter player name and create a new game
            Console.Write("Enter player name: ");
            var playerName = Console.ReadLine();
            Console.WriteLine("Welcome to the game: {0}", playerName);

             //create new instance of our Game class
            var game = new Game();

            //Until end of game is reached, continue bowling
            while (!game.EndOfGame)
            {
                Console.Write("Pens Bowled ");
                var pensbowled = Console.ReadLine();

                if (int.TryParse(pensbowled, out int pens))
                {
                    game.Bowl(pens);
                    Console.WriteLine($"Total Score: {game.GameScore}"); 
                }
                else 
                { Console.WriteLine("Invalid entry. Please try again."); }
                
            }
        }
    }
}
